﻿#!/bin/bash
# 🚀 Быстрая установка ProSushi Messenger на Debian 13 (от root)

echo "📦 Установка зависимостей..."

# Проверяем .NET
if ! command -v dotnet &> /dev/null; then
    echo "⚠️  .NET не найден, устанавливаю..."
    wget https://packages.microsoft.com/config/debian/12/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
    dpkg -i packages-microsoft-prod.deb
    rm packages-microsoft-prod.deb
    apt update
    apt install -y aspnetcore-runtime-8.0
else
    echo "✅ .NET уже установлен: $(dotnet --version)"
fi

echo ""
echo "📂 Создание папки приложения..."
mkdir -p /var/www/prosushimsg
cd /var/www/prosushimsg

echo ""
echo "📤 Распаковка архива..."
if [ -f /tmp/prosushi-release.zip ]; then
    unzip -o /tmp/prosushi-release.zip
    echo "✅ Архив распакован"
else
    echo "❌ Файл /tmp/prosushi-release.zip не найден!"
    echo "   Загрузи его через: scp prosushi-release.zip root@176.119.159.187:/tmp/"
    exit 1
fi

echo ""
echo "🔧 Настройка прав доступа..."
chown -R www-data:www-data /var/www/prosushimsg
chmod -R 755 /var/www/prosushimsg

echo ""
echo "⚙️  Установка systemd сервиса..."
if [ -f /tmp/prosushimsg.service ]; then
    cp /tmp/prosushimsg.service /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable prosushimsg
    echo "✅ Systemd сервис настроен"
else
    echo "⚠️  Файл /tmp/prosushimsg.service не найден"
    echo "   Загрузи его через: scp prosushimsg.service root@176.119.159.187:/tmp/"
fi

echo ""
echo "🚀 Запуск сервиса..."
systemctl stop prosushimsg 2>/dev/null
systemctl start prosushimsg

echo ""
echo "📊 Статус сервиса:"
systemctl status prosushimsg --no-pager -l

echo ""
echo "🎉 Установка завершена!"
echo ""
echo "📋 Полезные команды:"
echo "   - Логи:        journalctl -u prosushimsg -f"
echo "   - Рестарт:     systemctl restart prosushimsg"
echo "   - Статус:      systemctl status prosushimsg"
echo "   - Остановка:   systemctl stop prosushimsg"
echo ""
echo "🌐 Открой в браузере: https://chat.moviequotebot.ru"
